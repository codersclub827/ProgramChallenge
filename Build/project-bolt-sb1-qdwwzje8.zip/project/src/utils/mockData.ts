import { SensorData, AlertType } from '../types';
import { subHours } from 'date-fns';

export function generateMockData(hours: number): SensorData[] {
  const data: SensorData[] = [];
  const now = Date.now();

  for (let i = hours; i >= 0; i--) {
    const timestamp = subHours(now, i).getTime();
    data.push({
      timestamp,
      airQuality: {
        pm25: 20 + Math.random() * 30,
        co2: 400 + Math.random() * 200,
        aqi: 50 + Math.random() * 50
      },
      waterQuality: {
        pH: 6.5 + Math.random() * 1.5,
        turbidity: 2 + Math.random() * 3,
        tds: 200 + Math.random() * 100
      }
    });
  }

  return data;
}

export function generateMockAlerts(): AlertType[] {
  return [
    {
      type: 'danger',
      message: 'High PM2.5 levels detected in Sector A',
      timestamp: Date.now() - 1000 * 60 * 30
    },
    {
      type: 'warning',
      message: 'Water turbidity above normal in Treatment Plant 2',
      timestamp: Date.now() - 1000 * 60 * 120
    }
  ];
}