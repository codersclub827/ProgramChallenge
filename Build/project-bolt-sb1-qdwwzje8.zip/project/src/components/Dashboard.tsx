import React, { useEffect, useState } from 'react';
import { 
  LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, Legend,
  BarChart, Bar, PieChart, Pie, Cell, AreaChart, Area
} from 'recharts';
import { format } from 'date-fns';
import { AlertTriangle, Droplets, Wind, Activity, ThermometerSun, Gauge, TrendingUp, BarChart2 } from 'lucide-react';
import { SensorData, AlertType } from '../types';
import { generateMockData, generateMockAlerts } from '../utils/mockData';

const Dashboard: React.FC = () => {
  const [data, setData] = useState<SensorData[]>(() => generateMockData(24));
  const [alerts, setAlerts] = useState<AlertType[]>(() => generateMockAlerts());

  // Simulate real-time updates
  useEffect(() => {
    const interval = setInterval(() => {
      setData(prevData => {
        const newData = [...prevData.slice(1), {
          timestamp: Date.now(),
          airQuality: {
            pm25: 20 + Math.random() * 30,
            co2: 400 + Math.random() * 200,
            aqi: 50 + Math.random() * 50
          },
          waterQuality: {
            pH: 6.5 + Math.random() * 1.5,
            turbidity: 2 + Math.random() * 3,
            tds: 200 + Math.random() * 100
          }
        }];
        return newData;
      });
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const formatXAxis = (timestamp: number) => {
    return format(new Date(timestamp), 'HH:mm');
  };

  const getStatusColor = (value: number, type: 'pm25' | 'co2' | 'ph' | 'turbidity') => {
    const thresholds = {
      pm25: { warning: 35, danger: 50 },
      co2: { warning: 1000, danger: 2000 },
      ph: { warning: 8.5, danger: 9 },
      turbidity: { warning: 4, danger: 5 }
    };

    if (value > thresholds[type].danger) return 'text-red-600';
    if (value > thresholds[type].warning) return 'text-yellow-600';
    return 'text-green-600';
  };

  const getLatestReadings = () => {
    const latest = data[data.length - 1];
    return {
      pm25: latest.airQuality.pm25.toFixed(1),
      co2: latest.airQuality.co2.toFixed(0),
      ph: latest.waterQuality.pH.toFixed(1),
      turbidity: latest.waterQuality.turbidity.toFixed(1)
    };
  };

  const calculateAQIDistribution = () => {
    const categories = [
      { name: 'Good', value: 0 },
      { name: 'Moderate', value: 0 },
      { name: 'Poor', value: 0 }
    ];

    data.forEach(reading => {
      if (reading.airQuality.aqi <= 50) categories[0].value++;
      else if (reading.airQuality.aqi <= 100) categories[1].value++;
      else categories[2].value++;
    });

    return categories;
  };

  const COLORS = ['#4CAF50', '#FFC107', '#F44336'];

  const latestReadings = getLatestReadings();

  return (
    <div className="min-h-screen bg-gray-50">
      <div className="max-w-7xl mx-auto py-6 px-4 sm:px-6 lg:px-8">
        <div className="grid grid-cols-1 gap-6 lg:grid-cols-4">
          {/* Status Cards */}
          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <ThermometerSun className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">PM2.5</p>
                <p className={`text-2xl font-bold ${getStatusColor(parseFloat(latestReadings.pm25), 'pm25')}`}>
                  {latestReadings.pm25} µg/m³
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Wind className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">CO2</p>
                <p className={`text-2xl font-bold ${getStatusColor(parseFloat(latestReadings.co2), 'co2')}`}>
                  {latestReadings.co2} ppm
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Gauge className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">pH Level</p>
                <p className={`text-2xl font-bold ${getStatusColor(parseFloat(latestReadings.ph), 'ph')}`}>
                  {latestReadings.ph}
                </p>
              </div>
            </div>
          </div>

          <div className="bg-white rounded-lg shadow p-6">
            <div className="flex items-center">
              <Droplets className="h-8 w-8 text-blue-500" />
              <div className="ml-4">
                <p className="text-sm font-medium text-gray-600">Turbidity</p>
                <p className={`text-2xl font-bold ${getStatusColor(parseFloat(latestReadings.turbidity), 'turbidity')}`}>
                  {latestReadings.turbidity} NTU
                </p>
              </div>
            </div>
          </div>

          {/* Air Quality Trend */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <TrendingUp className="h-6 w-6 text-blue-500 mr-2" />
              <h2 className="text-xl font-semibold">Air Quality Trend Analysis</h2>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <AreaChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="timestamp" tickFormatter={formatXAxis} />
                  <YAxis />
                  <Tooltip
                    labelFormatter={(label) => format(new Date(label), 'HH:mm')}
                  />
                  <Legend />
                  <Area
                    type="monotone"
                    dataKey="airQuality.aqi"
                    stroke="#8884d8"
                    fill="#8884d8"
                    fillOpacity={0.3}
                    name="AQI"
                  />
                </AreaChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* AQI Distribution */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <BarChart2 className="h-6 w-6 text-blue-500 mr-2" />
              <h2 className="text-xl font-semibold">AQI Distribution</h2>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <PieChart>
                  <Pie
                    data={calculateAQIDistribution()}
                    cx="50%"
                    cy="50%"
                    labelLine={false}
                    label={({ name, percent }) => `${name} ${(percent * 100).toFixed(0)}%`}
                    outerRadius={80}
                    fill="#8884d8"
                    dataKey="value"
                  >
                    {calculateAQIDistribution().map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={COLORS[index % COLORS.length]} />
                    ))}
                  </Pie>
                  <Tooltip />
                </PieChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Pollutant Comparison */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <Wind className="h-6 w-6 text-blue-500 mr-2" />
              <h2 className="text-xl font-semibold">Air Quality Metrics</h2>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <LineChart data={data}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="timestamp" tickFormatter={formatXAxis} />
                  <YAxis />
                  <Tooltip
                    labelFormatter={(label) => format(new Date(label), 'HH:mm')}
                  />
                  <Legend />
                  <Line
                    type="monotone"
                    dataKey="airQuality.pm25"
                    stroke="#8884d8"
                    name="PM2.5"
                  />
                  <Line
                    type="monotone"
                    dataKey="airQuality.co2"
                    stroke="#82ca9d"
                    name="CO2"
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Water Quality Parameters */}
          <div className="lg:col-span-2 bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <Droplets className="h-6 w-6 text-blue-500 mr-2" />
              <h2 className="text-xl font-semibold">Water Quality Parameters</h2>
            </div>
            <div className="h-80">
              <ResponsiveContainer width="100%" height="100%">
                <BarChart data={[data[data.length - 1]]}>
                  <CartesianGrid strokeDasharray="3 3" />
                  <XAxis dataKey="timestamp" tickFormatter={formatXAxis} />
                  <YAxis />
                  <Tooltip />
                  <Legend />
                  <Bar dataKey="waterQuality.pH" fill="#8884d8" name="pH" />
                  <Bar dataKey="waterQuality.turbidity" fill="#82ca9d" name="Turbidity" />
                  <Bar dataKey="waterQuality.tds" fill="#ffc658" name="TDS" />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </div>

          {/* Alerts */}
          <div className="lg:col-span-4 bg-white rounded-lg shadow p-6">
            <div className="flex items-center mb-4">
              <AlertTriangle className="h-6 w-6 text-red-500 mr-2" />
              <h2 className="text-xl font-semibold">Real-time Alerts</h2>
            </div>
            <div className="space-y-4">
              {alerts.map((alert, index) => (
                <div
                  key={index}
                  className={`p-4 rounded-lg ${
                    alert.type === 'danger'
                      ? 'bg-red-50 border-l-4 border-red-500'
                      : 'bg-yellow-50 border-l-4 border-yellow-500'
                  }`}
                >
                  <div className="flex items-center">
                    <Activity className={`h-5 w-5 ${
                      alert.type === 'danger' ? 'text-red-500' : 'text-yellow-500'
                    } mr-2`} />
                    <div>
                      <p className={`text-sm ${
                        alert.type === 'danger' ? 'text-red-700' : 'text-yellow-700'
                      }`}>
                        {alert.message}
                      </p>
                      <p className="text-xs text-gray-500 mt-1">
                        {format(new Date(alert.timestamp), 'HH:mm')}
                      </p>
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </div>
    </div>
  );
};

export default Dashboard;