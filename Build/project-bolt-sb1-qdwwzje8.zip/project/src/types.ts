export interface SensorData {
  timestamp: number;
  airQuality: {
    pm25: number;
    co2: number;
    aqi: number;
  };
  waterQuality: {
    pH: number;
    turbidity: number;
    tds: number;
  };
}

export interface AlertType {
  type: 'warning' | 'danger';
  message: string;
  timestamp: number;
}